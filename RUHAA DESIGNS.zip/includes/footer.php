<div class="footer">
    <div class="page-container footer-container">
        <div class="footer-cities">
            <div class="footer-city">
                <a href="painting_list.html?city=Delhi">Paintings</a>
            </div>
            <div class="footer-city">
                <a href="sculpture_list.html?city=Mumbai">Sculpture</a>
            </div>
            <div class="footer-city">
                <a href="digitalArt_list.html?city=Bengaluru">Digital Art</a>
            </div>
            <div class="footer-city">
                <a href="propertylist_H.html?city=Hyderabad">Customized</a>
            </div>
        </div>
        <div class="footer-copyright">© 2021 Copyright by Muskan Gaba </div>
    </div>
</div>

<script type="text/javascript" src="js/jquery.js"></script>
<script type="text/javascript" src="js/bootstrap.min.js"></script>
<script type="text/javascript" src="js/common.js"></script>